using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "Fetching list of spam policies"

$ListType = $Request.Body.ListType
# Interact with query parameters or the body of the request.

if($ListType)
{
    $Result = Get-TenantAllowBlockListItems -ListType $ListType
    if($?){Write-Host "Successfully fetched list of tenants"}
    else
    {Write-Host "Failed to fetch list of tenants"}

}else{
    {Write-Host "Request failed : ListType Parameter not provided"} 
}
# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $Result
})