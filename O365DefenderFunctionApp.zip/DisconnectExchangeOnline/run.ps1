using namespace System.Net

# Input bindings are passed in via param block.
#param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "Initiating Disconnecting request...."

# Interact with query parameters or the body of the request.

Disconnect-ExchangeOnline -Confirm:$false
if($?)
{
    Write-Host "Disconnecting from exchange succesfull"
    $body = "Disconnecting from exchange successfull"

}else{
    
    Write-Host "Disconnecting from exchange failed"
    $body = "Disconnecting from exchange failed"
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})